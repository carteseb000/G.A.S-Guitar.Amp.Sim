function playGame() {
  window.open("scene1.html");
}
function quitGame() {
  window.close();
}
function pauseGame() {
  window.
  window.open("pause.html");
}